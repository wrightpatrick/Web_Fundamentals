var element = document.getElementById("liveImage");


function changePic(element){
    (liveImage.src = "img/succulents-2.jpg");
    
}

function changePicBack(element){
    (liveImage.src = "img/succulents-1.jpg");
    
}
var cookies = docujment.getElementById("cookiePolicy");

function remove(cookies){
     cookies = hidden;
}
    

